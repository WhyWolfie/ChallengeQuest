#include "stdafx.h"
#include "MBMatchMonitorCommunicator.h"
#include "MXml.h"
#include "MMatchServer.h"
#include "MMonitorDefine.h"

MBMatchMonitorCommunicator::MBMatchMonitorCommunicator()
{
}


MBMatchMonitorCommunicator::~MBMatchMonitorCommunicator()
{
}

bool MBMatchMonitorCommunicator::Send(const DWORD dwIP, const USHORT nPort, const string& strMonitorCommand)
{
	return MGetMatchServer()->SendMonitorUDP(dwIP, nPort, strMonitorCommand);
}

bool MBMatchMonitorCommunicator::Init()
{
	return true;
}


void MBMatchMonitorCommunicator::Release()
{
}