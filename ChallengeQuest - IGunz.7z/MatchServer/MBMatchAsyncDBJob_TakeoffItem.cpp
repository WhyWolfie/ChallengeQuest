#include "stdafx.h"
#include "MBMatchAsyncDBJob_TakeoffItem.h"


//void MBMatchAsyncDBJob_TakeoffItem::Run( void* pContext )
//{
//	MMatchDBMgr* pDBMgr = (MMatchDBMgr*)pContext;
//
//	if (!pDBMgr->UpdateEquipedItem(m_dwCID, m_Parts, 0, 0, &m_bRet))
//	{
//		SetResult( MASYNC_RESULT_FAILED );
//		return;
//	}
//
//	SetResult( MASYNC_RESULT_SUCCEED );
//}
