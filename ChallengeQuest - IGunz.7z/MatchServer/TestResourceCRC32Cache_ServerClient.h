#pragma once


void DoTestServerAndClient();