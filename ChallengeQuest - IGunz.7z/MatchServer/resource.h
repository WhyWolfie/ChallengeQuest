//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by MatchServer.rc
//
#define IDR_MANIFEST                    1
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_MatchServerTYPE             129
#define IDD_DIALOG_CONSOLE1             130
#define IDD_DIALOG_CONSOLE              130
#define IDS_STRING130                   130
#define ID_INDICATOR_SERVERSTATUS       130
#define IDR_POPUPMENU                   131
#define IDC_COMBO_COMMAND               1000
#define ID_ViewServerStatus             32772
#define ID__                            32776
#define ID_MENU_TERMINATE               32778
#define ID_MENU_HIDE                    32781
#define ID_MENU_SHOW                    32782
#define ID_Menu                         32783
#define ID_MESSAGE_EXIT                 32785
#define ID_SHOW_CMD_LOG                 32787
#define ID_UPDATE_IPtoCOUNTRY           32792
#define ID_UPDATE_BLOCK_COUNTRY_CODE    32793
#define ID_UPDATE_CUSTOM_IP             32794
#define ID_32795                        32795
#define ID_USE_COUNTRY_FILTER           32797
#define ID_ACCEPT_INVAILD_IP            32799
#define ID_TOOL_TEST                    32800
#define ID_TOOL_TEST32801               32801

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32802
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
