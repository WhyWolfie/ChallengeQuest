#include "stdafx.h"
#include "ZQuestMap.h"


ZQuestMap::ZQuestMap()
{

}

ZQuestMap::~ZQuestMap()
{

}

void ZQuestMap::Init()
{

}

void ZQuestMap::Final()
{

}
