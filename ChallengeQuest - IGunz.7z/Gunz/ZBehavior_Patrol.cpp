#include "stdafx.h"
#include "ZBehavior_Patrol.h"

void ZBehavior_Patrol::OnEnter()
{

}

void ZBehavior_Patrol::OnExit()
{

}

void ZBehavior_Patrol::OnRun(float fDelta)
{

}

ZBehavior_Patrol::ZBehavior_Patrol(ZBrain* pBrain) : ZBehaviorState(pBrain, ZBEHAVIOR_STATE_PATROL)
{

}

ZBehavior_Patrol::~ZBehavior_Patrol()
{

}
