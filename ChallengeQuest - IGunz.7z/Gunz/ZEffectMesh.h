#ifndef ZEFFECTMESH_H
#define ZEFFECTMESH_H

#include "ZEffectManager.h"
#include "RMesh.h"
/*
class ZEffectMeshSource{
protected:
	RealSpace2::RMesh*	m_pMesh;
public:
	ZEffectMeshSource(const char* szMeshName);
	virtual ~ZEffectMeshSource(void);

	void Draw(rvector &Pos, rvector &Dir, rvector &Up, rvector &Scale, float fOpacity);
};

class ZEffectMesh : public ZEffect{
protected:
	ZEffectMeshSource*	m_pEffectMeshSource;
	rvector				m_Pos;
public:
	ZEffectMesh(rvector& Pos, ZEffectMeshSource* pEffectMeshSource);
	virtual bool Draw(unsigned long int nTime);
	virtual rvector GetSortPos() {

		return m_Pos;
	}
};
*/

#endif