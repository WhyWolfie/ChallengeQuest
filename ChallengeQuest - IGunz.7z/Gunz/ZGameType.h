#ifndef _ZGAMETYPE_H
#define _ZGAMETYPE_H


#include "MBaseGameType.h"


class ZGameTypeManager : public MBaseGameTypeCatalogue
{
public:
	ZGameTypeManager();
	virtual ~ZGameTypeManager();
};










#endif