#include "stdafx.h"
#include "ZRuleTraining.h"


ZRuleTraining::ZRuleTraining(ZMatch* pMatch) : ZRuleSoloDeathMatch(pMatch)
{

}

ZRuleTraining::~ZRuleTraining()
{

}
