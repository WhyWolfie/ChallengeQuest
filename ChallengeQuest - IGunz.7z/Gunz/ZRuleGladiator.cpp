#include "stdafx.h"
#include "ZRuleGladiator.h"

ZRuleSoloGladiator::ZRuleSoloGladiator(ZMatch* pMatch) : ZRuleSoloDeathMatch(pMatch)
{

}

ZRuleSoloGladiator::~ZRuleSoloGladiator()
{

}


/////////////////////////////////////////////////////////////////////////////////////////


ZRuleTeamGladiator::ZRuleTeamGladiator(ZMatch* pMatch) : ZRuleTeamDeathMatch(pMatch)
{

}

ZRuleTeamGladiator::~ZRuleTeamGladiator()
{

}


