#pragma once

void MSysInfoLog();