#include "stdafx.h"
#include "ZGameType.h"

ZGameTypeManager::ZGameTypeManager()
{

}

ZGameTypeManager::~ZGameTypeManager()
{

}
