#ifndef _ZACTORSOUND_H
#define _ZACTORSOUND_H

#include <set>
using namespace std;

#include "MQuestNPC.h"


class ZActorSoundManager : public set<MQUEST_NPC>
{
private:
public:
	ZActorSoundManager() {}
	virtual ~ZActorSoundManager() {}
};




#endif