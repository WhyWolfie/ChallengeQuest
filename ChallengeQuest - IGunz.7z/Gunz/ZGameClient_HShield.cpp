#include "stdafx.h"

#include "ZGameClient.h"
#include "ZPost.h"

void OnPingHShield( const unsigned int nTimeStamp, const unsigned char* pbyAckMsg )
{
}