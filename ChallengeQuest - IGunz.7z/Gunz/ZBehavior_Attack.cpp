#include "stdafx.h"
#include "ZBehavior_Attack.h"

void ZBehavior_Attack::OnEnter()
{

}

void ZBehavior_Attack::OnExit()
{

}

void ZBehavior_Attack::OnRun(float fDelta)
{

}

ZBehavior_Attack::ZBehavior_Attack(ZBrain* pBrain) : ZBehaviorState(pBrain, ZBEHAVIOR_STATE_ATTACK)
{

}

ZBehavior_Attack::~ZBehavior_Attack()
{

}
