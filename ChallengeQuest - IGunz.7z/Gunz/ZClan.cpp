#include "stdafx.h"
#include "ZClan.h"
#include "ZGameInterface.h"
#include "ZGameClient.h"

ZClan::ZClan()
{

}

ZClan::~ZClan()
{

}


