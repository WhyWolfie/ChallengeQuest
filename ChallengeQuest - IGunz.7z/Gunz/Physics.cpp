#include "stdafx.h"

#include "Physics.h"

rvector ParabolicMotion(rvector& InitialVelocity, float fSec)
{
	return (0.5f * rvector(0, 0, -1)*GRAVITY_ACCELERATION * pow(fSec, 2) + InitialVelocity * fSec);
}
