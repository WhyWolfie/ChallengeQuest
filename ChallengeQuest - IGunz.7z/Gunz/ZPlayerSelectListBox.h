#pragma	once

#include "MListBox.h"

class ZPlayerSelectListBox : public MListBox {
public:
	ZPlayerSelectListBox(const char* szName, MWidget* pParent=NULL, MListener* pListener=NULL);
};
