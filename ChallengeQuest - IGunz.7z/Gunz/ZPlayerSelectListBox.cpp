#include "stdafx.h"
#include "ZPlayerSelectListBox.h"

ZPlayerSelectListBox::ZPlayerSelectListBox(const char* szName, MWidget* pParent, MListener* pListener)
:MListBox(szName,pParent,pListener)
{
}
