#include "stdafx.h"

#include "ZEffectMesh.h"
#include <crtdbg.h>

//�Ⱦ���~
/*

ZEffectMesh::ZEffectMesh(rvector& Pos, ZEffectMeshSource* pEffectMeshSource)
{
	m_pEffectMeshSource = pEffectMeshSource;
	m_Pos = Pos;
}

bool ZEffectMesh::Draw(unsigned long int nTime)
{
	if(m_bRender) {
		m_pEffectMeshSource->Draw(m_Pos, rvector(1, 0, 0), rvector(0, 0, 1), rvector(100, 100, 100), 1.0f);
		m_bisRendered = true;
	} 
	else {
		m_bisRendered = false;
	}
	return true;
}


ZEffectMeshSource::ZEffectMeshSource(const char* szMeshName)
{
	m_pMesh = new RealSpace2::RMesh;
	bool bRet = m_pMesh->ReadElu((char*)szMeshName);
	_ASSERT(bRet==true);
}

ZEffectMeshSource::~ZEffectMeshSource(void)
{
	delete m_pMesh;
}

void ZEffectMeshSource::Draw(rvector &Pos, rvector &Dir, rvector &Up, rvector &Scale, float fOpacity)
{
	rmatrix World;
	MakeWorldMatrix(&World, Pos, Dir, Up);
	m_pMesh->Render(&World);
}

*/