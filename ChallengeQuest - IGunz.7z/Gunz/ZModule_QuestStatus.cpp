#include "stdafx.h"
#include "ZModule_QuestStatus.h"


ZModule_QuestStatus::ZModule_QuestStatus() : ZModule(), m_nKills(0)
{
	
}

ZModule_QuestStatus::~ZModule_QuestStatus()
{

}


