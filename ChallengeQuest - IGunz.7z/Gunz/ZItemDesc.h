#ifndef _ZITEMDESC_H
#define _ZITEMDESC_H

#include "MXml.h"
#include <list>
#include <map>
#include "ZFilePath.h"
using namespace std;


#endif