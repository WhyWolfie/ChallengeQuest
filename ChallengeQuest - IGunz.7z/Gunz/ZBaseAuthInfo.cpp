#include "stdafx.h"
#include "ZBaseAuthInfo.h"


ZBaseAuthInfo::ZBaseAuthInfo()
{
	m_bTeenMode = false;
	m_ServerIP[0] = NULL;
	m_nServerPort = 0;
	m_CpCookie[0] = NULL;
}


