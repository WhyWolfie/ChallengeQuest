#include "StdAfx.h"
#include ".\zvisualmesh.h"

ZVisualMesh::ZVisualMesh()
{
}

ZVisualMesh::~ZVisualMesh()
{
}
