#include "stdafx.h"
#include "ZRuleBaseQuest.h"
#include "ZMatch.h"

ZRuleBaseQuest::ZRuleBaseQuest(ZMatch* pMatch) : ZRule(pMatch)
{

}

ZRuleBaseQuest::~ZRuleBaseQuest()
{

}
