#include "stdafx.h"
#include "ZBehavior_Script.h"

void ZBehavior_Script::OnEnter()
{

}

void ZBehavior_Script::OnExit()
{

}

void ZBehavior_Script::OnRun(float fDelta)
{

}

ZBehavior_Script::ZBehavior_Script(ZBrain* pBrain) : ZBehaviorState(pBrain, ZBEHAVIOR_STATE_SCRIPT)
{

}

ZBehavior_Script::~ZBehavior_Script()
{

}
