#include "stdafx.h"
#include "ZRuleSurvival.h"
#include "ZMatch.h"

ZRuleSurvival::ZRuleSurvival(ZMatch* pMatch) : ZRuleBaseQuest(pMatch)
{

}

ZRuleSurvival::~ZRuleSurvival()
{

}
