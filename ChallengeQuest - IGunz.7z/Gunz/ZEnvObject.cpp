#include "stdafx.h"
#include "ZEnvObject.h"
/*
MImplementRTTI(ZEnvObject, ZActor);

*/