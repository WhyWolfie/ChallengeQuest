#ifndef _ZTESTGAME_H
#define _ZTESTGAME_H

void CreateTestGame(char *mapname, int nDummyCharacterCount = 0, bool bShot = false,bool bAITest = false, int nParam1=0);

#endif