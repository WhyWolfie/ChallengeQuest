#ifndef _ZACTORCONTROLLER_H
#define _ZACTORCONTROLLER_H


class ZActorController
{
private:
	
public:
	ZActorController();
	virtual ~ZActorController();
	void Clear();
};





#endif