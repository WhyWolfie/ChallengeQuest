#include "stdafx.h"
#include "ZBehavior_Attack2.h"

void ZBehavior_Attack2::OnEnter()
{

}

void ZBehavior_Attack2::OnExit()
{

}

void ZBehavior_Attack2::OnRun(float fDelta)
{

}

ZBehavior_Attack2::ZBehavior_Attack2(ZBrain2* pBrain) : ZBehaviorState2(pBrain, ZBEHAVIOR_STATE_ATTACK)
{

}

ZBehavior_Attack2::~ZBehavior_Attack2()
{

}
