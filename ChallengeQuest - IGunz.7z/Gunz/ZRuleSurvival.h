#ifndef _ZRULE_SURVIVAL_H
#define _ZRULE_SURVIVAL_H


#include "ZRule.h"
#include "ZRuleBaseQuest.h"


class ZRuleSurvival : public ZRuleBaseQuest
{
public:
	ZRuleSurvival(ZMatch* pMatch);
	virtual ~ZRuleSurvival();
};




#endif