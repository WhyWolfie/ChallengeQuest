#ifndef _ZRULE_BASE_QUEST_H
#define _ZRULE_BASE_QUEST_H


#include "ZRule.h"


class ZRuleBaseQuest : public ZRule
{
protected:

public:
	ZRuleBaseQuest(ZMatch* pMatch);
	virtual ~ZRuleBaseQuest();
};



#endif